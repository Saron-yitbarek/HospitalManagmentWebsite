﻿using Hospital_Management_System.Models.Base;
using Hospital_Management_System.Models.Doctor;

namespace Hospital_Management_System.Models.Services
{
    public interface IPrescribeDrugServices : IEntityBaseRepository<PrescribeDrug>
    {
    }
}
